from django.contrib import admin

# Register your models here.
from .models import details,Reports
admin.site.register(details)
admin.site.register(Reports)