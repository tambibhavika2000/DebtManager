import sys
import datetime
from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from .models import details ,Reports
from django.contrib.auth import authenticate,  login, logout
from django.core.files.storage import FileSystemStorage
from subprocess import run,PIPE,Popen
from django.db.models import Sum
def home(request):
    labels=[]
    data=[]
    queryset= Reports.objects.filter(user=loginuser_name()).order_by("month")
    for i in queryset:
        labels.append(i.month.strftime('%B'))
        data.append(i.saving)
    print(labels)
    print(data)
    return render(request, "manager/home.html",{'labels':labels,'data':data})

def index(request):
    return render(request, "manager/index.html")

def userlogin(request):
    return render(request,"manager/login.html")

def update(request):
    return render(request,"manager/update.html")

def credits(request):
    sum_credit = Reports.objects.filter(user=loginuser_name()).aggregate(Sum('credit'))
    sum_detail = {'sum': sum_credit['credit__sum']}
    return render(request,"manager/credits.html",sum_detail)

def report(request):
    data1=Reports.objects.filter(user=loginuser_name())
    data2 = Reports.objects.filter(user=loginuser_name()).aggregate(Sum('saving'))
    data3 = Reports.objects.filter(user=loginuser_name()).aggregate(Sum('credit'))
    context = {'table_list': data1,'saved':data2['saving__sum'], 'rewards':data3['credit__sum']}
    return render(request,"manager/report.html",context)

def registers(request):
     return render(request,"manager/registers.html")

def add_user(request):
    if request.method == "POST":
        # Get the post parameters
        uname = request.POST['uname']
        lname=request.POST['lname']
        ename = request.POST['ename']
        upsw = request.POST['upsw']
        cpsw = request.POST['cpsw']
        if(upsw==cpsw):
            myuser = User.objects.create_user(uname,ename,upsw)
            myuser.first_name=uname
            myuser.last_name=lname
            myuser.set_password=upsw
            myuser.save()
            return render(request, "manager/login.html")
    else:
        return HttpResponse("404 - Not found")

def login_validation(request):
    if request.method=="POST":
        loginusername=request.POST['loginuname']
        loginpassword=request.POST['loginpsw']
        global loginuser_name
        def loginuser_name():
            return loginusername
        request.session['user']=loginusername
        print(request.session['user'])
        user=authenticate(username= loginusername, password= loginpassword)
        if user is not None:
            login(request, user)
            return render(request, "manager/front.html")
        else:
            return HttpResponse("Loginfailed")

    return HttpResponse("404- Not found")

def logout(request):
    return render(request, "manager/login.html")

def update(request):
    # if  request.method=="POST":
        # image=request.FILES["image"]
        # document=Fileuploads.objects.create(file=image)
        # document.save()
        # return render(request, "manager/report.html")
    return render(request,"manager/update.html")

def external(request):
    # print(request.session['user'])
    user_name=loginuser_name()
    image = request.FILES["image"]
    fs=FileSystemStorage()
    filename=fs.save(image.name,image)
    fileurl=fs.open(filename)
    # print("file name " ,fileurl)
    out=Popen([sys.executable,r'C:\Users\Bhavika\PycharmProjects\DebtManager\dm\manager\textextract.py',str(fileurl),str(filename)],shell=True,stdout=PIPE).stdout
    # encoding="utf-8"
    # temp=out.decode(encoding)
    # temp =out.encode.decode('UTF-8', 'ignore')
    # Actual start here
    temp=out.read().decode()
    temp1=temp[2:len(temp)-4]
    temp2=float(temp1.replace(',',''))
    document = details.objects.create(owner=user_name, file=image, amount=temp2)
    document.save()
    previouswaala= Reports.objects.filter(user=user_name).last().spend
    if(previouswaala is None):
        previouswaala=temp2
    diff=temp2-previouswaala
    # print(diff)
    if(diff<=0):
        x=0
    else:
        x=diff
    x= round(x,2)
    # Fraction calculation
    prev_month=Reports.objects.filter(user='prachi').last().month
    today_date=datetime.date.today()
    a=(abs(prev_month-today_date).days)
    fraction=a/31;
    # print(fraction)

    #credit calculation
    prev_sav = Reports.objects.filter(user='prachi').last().saving
    credit_val=(x//prev_sav)*100;
    # print(credit_val)
    if credit_val in range(0,5):
        y=0
    if credit_val in range(5,20):
        y=1
    elif credit_val in range(20,30):
        y=3
    elif credit_val in range(40,60):
        y=6
    elif credit_val in range(60,70):
        y=10
    elif credit_val in range(70,90):
        y=12
    else:
        y=15
    print(y)
    final_cred=y*fraction;
    t=round(final_cred,2)
    if(a>28):
        report_update=Reports.objects.create(user=user_name , month=datetime.date.today(),spend=temp2 ,saving=x ,credit=t)
        report_update.save()
        message='Amount Extracted: '+ str(temp2)
        color='alert-primary'
    else:
        message='Screenshots should be updated minimum after 30 days'
        color='alert-warning'
    return render(request, "manager/update.html",{'output':message,'color':color})
