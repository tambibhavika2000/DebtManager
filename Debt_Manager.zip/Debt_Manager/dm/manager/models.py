from datetime import date
from django.db import models

class Users(models.Model):
    user_id=models.AutoField
    user_name=models.CharField(max_length=50)
    user_contact= models.IntegerField()
    user_email = models.CharField(max_length=50,unique=True)

    def __str__(self):
        return self.user_name


class details(models.Model):
    owner=models.CharField(max_length=50 )
    file=models.FileField()
    amount=models.FloatField(default=0)

    class Meta:
        verbose_name_plural = 'Details'

class Reports(models.Model):
    user=models.CharField(max_length=50)
    month=models.DateField(default=date.today)
    spend=models.FloatField(default=0)
    saving=models.FloatField(default=0)
    credit=models.FloatField(default=0)

    def __str__(self):
        return self.user

    class Meta:
        verbose_name_plural = 'Reports'
