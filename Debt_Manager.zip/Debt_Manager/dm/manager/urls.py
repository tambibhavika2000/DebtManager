from django.contrib import admin
from django.urls import path
from . import views
from django.conf.urls import url

urlpatterns = [
    path("", views.userlogin , name="dmlogin"),
    path("index/", views.index , name="dmindex"),
    path("registers/", views.registers , name="dmregisters"),
    path("add_user", views.add_user , name="dmadd_user"),
    path("login_validation", views.login_validation, name="dmlogin_validation"),
    path("logout", views.logout , name="dmlogout"),
    path("home/", views.home , name="dmhome"),
    path("update/", views.update , name="dmhome"),
    path("report/", views.report , name="dmreport"),
    path("credits/", views.credits , name="dmcredit"),
    url(r'^external', views.external, name="dmexternal"),
]
