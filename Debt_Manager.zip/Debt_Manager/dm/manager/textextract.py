from matplotlib import pyplot as plt
from PIL import Image
import pytesseract
import argparse
import cv2
import os
import re
from GPSPhoto import gpsphoto
from PIL.ExifTags import TAGS
import sys
import os.path
import time
import subprocess

image_fullpath=sys.argv[1]
image_name=sys.argv[2]
img = cv2.imread(str(image_fullpath),0)
filename = "{}.png".format(os.getpid())
cv2.imwrite(filename, img)


pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract"
text = pytesseract.image_to_string(Image.open(filename))
match = re.findall("([0-9]+[,.]+[0-9]+[,.]+[0-9]+[0-9])", text)
print(match)

# infoDict = {} #Creating the dict to get the metadata tags
# exifToolPath = r'C:\Users\Bhavika\Downloads\exiftool-12.10\exiftool.exe' #for Windows user have to specify the Exif tool exe path for metadata extraction.
#
# ''' use Exif tool to get the metadata '''
# process = subprocess.Popen([exifToolPath,image_fullpath],stdout=subprocess.PIPE, stderr=subprocess.STDOUT,universal_newlines=True)
# ''' get the tags in dict '''
# for tag in process.stdout:
#     line = tag.strip().split(':')
#     infoDict[line[0].strip()] = line[-1].strip()
#

# for k,v in infoDict.items():
#     print(k,':', v)
# extract EXIF data


# dict1=image._getexif()
# print(dict1)
# for tags , values in dict1.items():
#     print(tag,values)

# image_list = os.listdir(image_fullpath)
# for a in image_list:
#      data = gpsphoto.getGPSData(os.getcwd() + f'\\{a}')
#      print(data)

# filepath=os.path.abspath(image_fullpath)
# print('File         :', filepath)
# print('Access time  :', time.ctime(os.path.getatime(filepath)))
# print('Modified time:', time.ctime(os.path.getmtime(filepath)))
# print('Change time  :', time.ctime(os.path.getctime(filepath)))
# print('Size         :', os.path.getsize(os.path.abspath(filepath)))
