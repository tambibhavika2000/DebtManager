from django.http import HttpResponse
from django.shortcuts import render
from .models import FileUpload
def login(request):
    return HttpResponse("Login Page")

def profile(request):
    if request.method=='POST':
        file2=request.FILES["file"]
        document=FileUpload.objects.create(file=file2)
        document.save()
        return HttpResponse("Sucessfull Upload")
    return render(request, 'profile.html')