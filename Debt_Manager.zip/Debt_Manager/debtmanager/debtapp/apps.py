from django.apps import AppConfig


class DebtappConfig(AppConfig):
    name = 'debtapp'
